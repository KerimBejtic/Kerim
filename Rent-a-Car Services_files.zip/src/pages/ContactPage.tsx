import  { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send, Instagram } from 'lucide-react';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      setFormData({
        name: '',
        email: '',
        phone: '',
        message: '',
      });
      
      // Reset success message after 5 seconds
      setTimeout(() => {
        setSubmitSuccess(false);
      }, 5000);
    }, 1500);
  };

  return (
    <>
      {/* Header */}
      <section className="bg-primary text-white py-20">
        <div className="container-custom">
          <h1 className="text-4xl font-bold mb-4">Kontaktirajte nas</h1>
          <p className="text-xl max-w-2xl">
            Imate pitanje ili želite rezervisati vozilo? Kontaktirajte nas putem forme ili direktno na naš telefon.
          </p>
        </div>
      </section>

      {/* Contact Section */}
      <section className="section">
        <div className="container-custom">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Pošaljite upit</h2>
              {submitSuccess ? (
                <div className="bg-green-100 p-4 rounded-md mb-6">
                  <p className="text-green-700 font-medium">Vaša poruka je uspješno poslana! Kontaktirat ćemo vas u najkraćem mogućem roku.</p>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="mb-4">
                    <label htmlFor="name" className="block mb-2 font-medium">
                      Ime i prezime
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="email" className="block mb-2 font-medium">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    />
                  </div>
                  <div className="mb-4">
                    <label htmlFor="phone" className="block mb-2 font-medium">
                      Telefon
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                  </div>
                  <div className="mb-6">
                    <label htmlFor="message" className="block mb-2 font-medium">
                      Poruka
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={5}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      required
                    ></textarea>
                  </div>
                  <button
                    type="submit"
                    className="btn btn-primary flex items-center"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <span>Šaljem...</span>
                    ) : (
                      <>
                        <Send className="h-5 w-5 mr-2" />
                        <span>Pošalji upit</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>

            {/* Contact Info */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Kontakt informacije</h2>
              <div className="bg-light p-6 rounded-lg shadow-sm mb-8">
                <ul className="space-y-6">
                  <li className="flex items-start">
                    <Phone className="h-6 w-6 text-primary mr-4 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">Telefon</h3>
                      <p className="text-gray-700">+387 62 557 300</p>
                      <p className="text-gray-700">+387 66 720 004</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Mail className="h-6 w-6 text-primary mr-4 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">Email</h3>
                      <p className="text-gray-700">rentacarfortuna@gmail.com</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <MapPin className="h-6 w-6 text-primary mr-4 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">Adresa</h3>
                      <p className="text-gray-700">Ilidža, Sarajevo</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Clock className="h-6 w-6 text-primary mr-4 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">Radno vrijeme</h3>
                      <p className="text-gray-700">Svaki dan: 10:00 - 22:00</p>
                    </div>
                  </li>
                  <li className="flex items-start">
                    <Instagram className="h-6 w-6 text-primary mr-4 flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">Instagram</h3>
                      <a 
                        href="https://www.instagram.com/rentcarfortuna?igsh=MWJ4emd6dnd4eDJiZw%3D%3D&utm_source=qr" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-primary hover:underline"
                      >
                        @rentcarfortuna
                      </a>
                    </div>
                  </li>
                </ul>
              </div>

              <h3 className="text-xl font-semibold mb-4">Jezici</h3>
              <p className="mb-6 text-gray-700">
                Naš ljubazni tim govori bosanski i engleski jezik, kako bismo mogli pružiti podršku i domaćim i stranim klijentima.
              </p>

              <h3 className="text-xl font-semibold mb-4">Besplatna dostava vozila</h3>
              <p className="text-gray-700">
                Nudimo besplatnu dostavu vozila na željenu lokaciju unutar Sarajeva i okolice. Vozilo možemo dostaviti na aerodrom, hotel ili bilo koju drugu adresu po vašem izboru.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="section bg-light">
        <div className="container-custom">
          <h2 className="section-title">Naša lokacija</h2>
          <div className="bg-white p-4 rounded-lg shadow-sm overflow-hidden">
            <div className="aspect-w-16 aspect-h-9 h-96">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11570.063771087952!2d18.293928695727542!3d43.83148080000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4758cbfe31ced93d%3A0xa52ab3603e3c9aa8!2sIlid%C5%BEa%2C%20Sarajevo%2C%20Bosnia%20and%20Herzegovina!5e0!3m2!1sen!2sus!4v1714324351761!5m2!1sen!2sus" 
                className="w-full h-full border-0"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Lokacija Fortuna Rent a Car"
              ></iframe>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default ContactPage;
  