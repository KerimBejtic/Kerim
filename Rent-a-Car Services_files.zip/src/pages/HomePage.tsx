import  { Link } from 'react-router-dom';
import { Check, Car, Calendar, CreditCard, MapPin, Users } from 'lucide-react';

const HomePage = () => {
  return (
    <>
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1515569067071-ec3b51335dd0?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200"
            alt="Luksuzni automobil"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-dark bg-opacity-60"></div>
        </div>
        
        <div className="container-custom relative z-10 text-white">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Fortuna Rent a Car</h1>
            <p className="text-xl mb-8">Iznajmite vozilo po najpovoljnijim cijenama u Sarajevu uz besplatnu dostavu na lokaciju.</p>
            <div className="flex flex-wrap gap-4">
              <a href="sms:+38762557300" className="btn btn-secondary">
                Contact Me
              </a>
              <Link to="/usluge" className="btn btn-outline border-white text-white hover:bg-white hover:text-dark">
                Naše usluge
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* About Us Section */}
      <section className="section bg-light">
        <div className="container-custom">
          <h2 className="section-title">O nama</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-lg mb-6">
                Fortuna Rent a Car je pouzdana rent-a-car kuća sa sjedištem na Ilidži, koja nudi širok spektar kvalitetnih vozila za iznajmljivanje
                po konkurentnim cijenama.
              </p>
              <p className="text-lg mb-6">
                Ono što nas izdvaja od konkurencije je naša posvećenost zadovoljstvu klijenata, fleksibilnost i usluga besplatne dostave
                vozila na željenu lokaciju.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Pouzdana vozila</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Fleksibilne cijene</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>Besplatna dostava</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-5 w-5 text-secondary" />
                  <span>24/7 podrška</span>
                </div>
              </div>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1532751203793-812308a10d8e?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200"
                alt="Luksuzno vozilo"
                className="rounded-lg shadow-lg w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="section">
        <div className="container-custom">
          <h2 className="section-title">Naše usluge</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="card p-6">
              <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Car className="h-7 w-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Iznajmljivanje vozila</h3>
              <p className="text-gray-600 mb-4">
                Iznajmite vozilo po vašem izboru na dnevnoj, sedmičnoj ili mjesečnoj osnovi po konkurentnim cijenama.
              </p>
              <Link to="/usluge" className="text-primary font-medium hover:underline">
                Saznajte više
              </Link>
            </div>
            
            <div className="card p-6">
              <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Users className="h-7 w-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Vozila s vozačem</h3>
              <p className="text-gray-600 mb-4">
                Ukoliko želite dodatnu udobnost, nudimo i uslugu iznajmljivanja vozila s profesionalnim vozačem.
              </p>
              <Link to="/usluge" className="text-primary font-medium hover:underline">
                Saznajte više
              </Link>
            </div>
            
            <div className="card p-6">
              <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <MapPin className="h-7 w-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Besplatna dostava</h3>
              <p className="text-gray-600 mb-4">
                Dostavljamo vozilo besplatno na željenu lokaciju unutar Sarajeva i okolice.
              </p>
              <Link to="/usluge" className="text-primary font-medium hover:underline">
                Saznajte više
              </Link>
            </div>
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/usluge" className="btn btn-primary">
              Pogledajte sve usluge
            </Link>
          </div>
        </div>
      </section>
      
      {/* Featured Cars */}
      <section className="section bg-light">
        <div className="container-custom">
          <h2 className="section-title">Naša vozila</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="card">
              <div className="h-56 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1485463611174-f302f6a5c1c9?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHw1fHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200" 
                  alt="Luksuzni sedan" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Luksuzni sedan</h3>
                <div className="flex items-center space-x-2 text-gray-500 mb-4">
                  <Users className="h-4 w-4" />
                  <span>5 osoba</span>
                </div>
                <p className="text-gray-600 mb-4">
                  Udoban i prostranih luksuzni sedan za poslovna putovanja ili posebne prilike.
                </p>
                <a href="sms:+38762557300" className="btn btn-outline w-full">
                  Contact Me
                </a>
              </div>
            </div>
            
            <div className="card">
              <div className="h-56 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1517676109075-9a94d44145d1?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHw0fHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200" 
                  alt="SUV vozilo" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">SUV</h3>
                <div className="flex items-center space-x-2 text-gray-500 mb-4">
                  <Users className="h-4 w-4" />
                  <span>5 osoba</span>
                </div>
                <p className="text-gray-600 mb-4">
                  Prostrano SUV vozilo idealno za porodična putovanja i vožnju po različitim terenima.
                </p>
                <a href="sms:+38762557300" className="btn btn-outline w-full">
                  Contact Me
                </a>
              </div>
            </div>
            
            <div className="card">
              <div className="h-56 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1485463611174-f302f6a5c1c9?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHw1fHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200" 
                  alt="Sportski automobil" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Sportski automobil</h3>
                <div className="flex items-center space-x-2 text-gray-500 mb-4">
                  <Users className="h-4 w-4" />
                  <span>2 osobe</span>
                </div>
                <p className="text-gray-600 mb-4">
                  Doživite uzbuđenje vožnje u sportskom automobilu za posebne trenutke.
                </p>
                <a href="sms:+38762557300" className="btn btn-outline w-full">
                  Contact Me
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Benefits */}
      <section className="section">
        <div className="container-custom">
          <h2 className="section-title">Zašto izabrati nas?</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <div className="text-center p-6">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <CreditCard className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Fleksibilne cijene</h3>
              <p className="text-gray-600">
                Prilagođavamo cijene prema dužini najma i vrsti vozila.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Calendar className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Jednostavna rezervacija</h3>
              <p className="text-gray-600">
                Brz i jednostavan proces rezervacije vozila.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Check className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Kvalitetna vozila</h3>
              <p className="text-gray-600">
                Sva vozila redovno održavana i u odličnom stanju.
              </p>
            </div>
            
            <div className="text-center p-6">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-primary" />
              </div>
              <h3 className="font-semibold mb-2">Besplatna dostava</h3>
              <p className="text-gray-600">
                Dostavljamo vozilo na vašu adresu bez dodatne naknade.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* CTA */}
      <section className="relative py-20">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1498887960847-2a5e46312788?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwzfHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200"
            alt="Automobil na cesti"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-dark bg-opacity-70"></div>
        </div>
        
        <div className="container-custom relative z-10 text-white text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Spremni za putovanje?</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">
            Rezervišite vozilo već danas i uživajte u bezbrižnom putovanju sa Fortuna Rent a Car.
          </p>
          <a href="sms:+38762557300" className="btn btn-secondary">
            Contact Me
          </a>
        </div>
      </section>
    </>
  );
};

export default HomePage;
  