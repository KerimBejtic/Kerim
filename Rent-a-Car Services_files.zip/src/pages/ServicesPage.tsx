import  { Link } from 'react-router-dom';
import { Car, Users, Clock, Calendar, MapPin, Check } from 'lucide-react';

const ServicesPage = () => {
  return (
    <>
      {/* Header */}
      <section className="bg-primary text-white py-20">
        <div className="container-custom">
          <h1 className="text-4xl font-bold mb-4">Naše usluge</h1>
          <p className="text-xl max-w-2xl">
            Otkrijte širok spektar usluga koje nudimo našim klijentima, od iznajmljivanja vozila do posebnih ponuda.
          </p>
        </div>
      </section>

      {/* Services List */}
      <section className="section">
        <div className="container-custom">
          <div className="grid gap-16">
            {/* Service 1 */}
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <Car className="h-7 w-7 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-4">Iznajmljivanje vozila</h2>
                <p className="text-gray-600 mb-6">
                  Nudimo raznovrstan vozni park za sve vaše potrebe, bilo da trebate ekonomično vozilo za gradsku vožnju 
                  ili luksuzni automobil za posebne prilike.
                </p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Dnevni najam (24h)</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Sedmični najam (7 dana)</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Mjesečni najam (30 dana)</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Dugoročni najam (po dogovoru)</span>
                  </li>
                </ul>
                <a href="sms:+38762557300" className="btn btn-primary">
                  Contact Me
                </a>
              </div>
              <div>
                <img
                  src="https://images.unsplash.com/photo-1485463611174-f302f6a5c1c9?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHw1fHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200"
                  alt="Iznajmljivanje vozila"
                  className="rounded-lg shadow-lg w-full h-auto"
                />
              </div>
            </div>

            {/* Service 2 */}
            <div className="grid md:grid-cols-2 gap-8 items-center md:order-2">
              <div>
                <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <Users className="h-7 w-7 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-4">Iznajmljivanje vozila s vozačem</h2>
                <p className="text-gray-600 mb-6">
                  Ukoliko želite dodatnu udobnost i sigurnost, nudimo uslugu iznajmljivanja vozila s profesionalnim vozačem,
                  idealno za poslovne sastanke, svečanosti ili razgledavanje grada.
                </p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Profesionalni vozači s iskustvom</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Usluga dostupna po satu ili dnevno</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Posebne ponude za turističke ture</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Mogućnost rezervacije za posebne događaje</span>
                  </li>
                </ul>
                <a href="sms:+38762557300" className="btn btn-primary">
                  Contact Me
                </a>
              </div>
              <div className="md:order-1">
                <img
                  src="https://images.unsplash.com/photo-1532751203793-812308a10d8e?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwyfHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200"
                  alt="Vozilo s vozačem"
                  className="rounded-lg shadow-lg w-full h-auto"
                />
              </div>
            </div>

            {/* Service 3 */}
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                  <MapPin className="h-7 w-7 text-primary" />
                </div>
                <h2 className="text-2xl font-bold mb-4">Besplatna dostava vozila</h2>
                <p className="text-gray-600 mb-6">
                  Pružamo besplatnu dostavu vozila na željenu lokaciju unutar Sarajeva i okolice. 
                  Vozilo možemo dostaviti na aerodrom, hotel ili bilo koju drugu adresu po vašem izboru.
                </p>
                <ul className="space-y-3 mb-6">
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Dostava na Sarajevski aerodrom</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Dostava u hotele i apartmane</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Dostava na kućnu adresu</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="h-5 w-5 text-secondary" />
                    <span>Fleksibilno vrijeme dostave</span>
                  </li>
                </ul>
                <a href="sms:+38762557300" className="btn btn-primary">
                  Contact Me
                </a>
              </div>
              <div>
                <img
                  src="https://images.unsplash.com/photo-1515569067071-ec3b51335dd0?ixid=M3w3MjUzNDh8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBjYXIlMjByZW50YWwlMjBmbGVldHxlbnwwfHx8fDE3NDM1MTg0MDh8MA&ixlib=rb-4.0.3&fit=fillmax&h=800&w=1200"
                  alt="Dostava vozila"
                  className="rounded-lg shadow-lg w-full h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Additional benefits */}
      <section className="section bg-light">
        <div className="container-custom">
          <h2 className="section-title">Dodatne pogodnosti</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="card p-6">
              <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Calendar className="h-7 w-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Fleksibilno rezerviranje</h3>
              <p className="text-gray-600">
                Mogućnost besplatnog otkazivanja ili promjene rezervacije do 48 sati prije preuzimanja vozila.
              </p>
            </div>
            
            <div className="card p-6">
              <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Clock className="h-7 w-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">24/7 podrška</h3>
              <p className="text-gray-600">
                Naš tim je dostupan za pomoć u bilo koje doba dana ili noći u slučaju bilo kakvih problema.
              </p>
            </div>
            
            <div className="card p-6">
              <div className="w-14 h-14 mb-4 rounded-full bg-primary/10 flex items-center justify-center">
                <Check className="h-7 w-7 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Redovno održavanje</h3>
              <p className="text-gray-600">
                Sva naša vozila su redovno servisirana i održavana kako bi osigurali vašu sigurnost i udobnost.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section bg-primary text-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold mb-6">Spremni iznajmiti vozilo?</h2>
          <p className="text-xl max-w-2xl mx-auto mb-8">
            Kontaktirajte nas danas za više informacija o našim uslugama ili da rezervišete vozilo.
          </p>
          <a href="sms:+38762557300" className="btn btn-secondary">
            Contact Me
          </a>
        </div>
      </section>
    </>
  );
};

export default ServicesPage;
  