import  { Link } from 'react-router-dom';
import { Car, Phone, Mail, MapPin, Clock, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-dark text-white py-12">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <Car className="h-7 w-7 text-secondary" />
              <span className="text-xl font-bold">Fortuna Rent a Car</span>
            </div>
            <p className="text-gray-300 mb-4">
              Pružamo vrhunsku uslugu iznajmljivanja vozila s fleksibilnim cijenama i besplatnom dostavom na lokaciju.
            </p>
            <a href="sms:+38762557300" className="btn btn-secondary">
              Contact Me
            </a>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Kontaktirajte nas</h3>
            <ul className="space-y-3 text-gray-300">
              <li className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-secondary" />
                <span>+387 62 557 300</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone className="h-5 w-5 text-secondary" />
                <span>+387 66 720 004</span>
              </li>
              <li className="flex items-center space-x-2">
                <Mail className="h-5 w-5 text-secondary" />
                <span>rentacarfortuna@gmail.com</span>
              </li>
              <li className="flex items-start space-x-2">
                <MapPin className="h-5 w-5 flex-shrink-0 text-secondary" />
                <span>Ilidža, Sarajevo</span>
              </li>
              <li className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-secondary" />
                <span>Svaki dan: 10:00-22:00</span>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Pratite nas</h3>
            <div className="flex space-x-3 mb-6">
              <a href="https://www.instagram.com/rentcarfortuna?igsh=MWJ4emd6dnd4eDJiZw%3D%3D&utm_source=qr" target="_blank" rel="noopener noreferrer" 
                 className="bg-white bg-opacity-10 p-2 rounded-full hover:bg-secondary transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
            </div>
            <h3 className="text-lg font-semibold mb-2">Jezici</h3>
            <p className="text-gray-300">Bosanski, Engleski</p>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-10 pt-6 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Fortuna Rent a Car. Sva prava pridržana.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
  