import  { useState } from 'react';
import { Link, NavLink } from 'react-router-dom';
import { Car, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navItems = [
    { name: 'Početna', path: '/' },
    { name: 'Usluge', path: '/usluge' },
    { name: 'Kontakt', path: '/kontakt' },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container-custom py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center space-x-2">
          <Car className="h-8 w-8 text-primary" />
          <span className="text-xl font-bold text-primary">Fortuna Rent a Car</span>
        </Link>

        <nav className="hidden md:flex items-center space-x-8">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              className={({ isActive }) =>
                isActive
                  ? 'font-medium text-secondary'
                  : 'font-medium text-dark hover:text-primary transition-colors'
              }
            >
              {item.name}
            </NavLink>
          ))}
          <a href="sms:+38762557300" className="btn btn-primary">
            Contact Me
          </a>
        </nav>

        <button className="md:hidden text-dark" onClick={toggleMenu}>
          <Menu className="h-6 w-6" />
        </button>
      </div>

      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="fixed inset-0 bg-dark bg-opacity-50 z-50">
          <div className="bg-white h-full w-4/5 max-w-sm p-5 shadow-lg">
            <div className="flex justify-between items-center mb-8">
              <Link to="/" className="flex items-center space-x-2">
                <Car className="h-7 w-7 text-primary" />
                <span className="text-lg font-bold text-primary">Fortuna</span>
              </Link>
              <button onClick={toggleMenu}>
                <X className="h-6 w-6 text-dark" />
              </button>
            </div>
            <nav className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  className={({ isActive }) =>
                    isActive
                      ? 'font-medium text-secondary'
                      : 'font-medium text-dark hover:text-primary transition-colors'
                  }
                  onClick={toggleMenu}
                >
                  {item.name}
                </NavLink>
              ))}
              <a href="sms:+38762557300" className="btn btn-primary mt-4" onClick={toggleMenu}>
                Contact Me
              </a>
            </nav>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
  